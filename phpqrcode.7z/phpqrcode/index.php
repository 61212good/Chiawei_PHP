<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <link rel="icon" sizes="192x192" href="images/ico_1.png">
    <link rel="apple-touch-icon" sizes="192x192" href="images/ico_1.png">
    <meta name="theme-color" content="#ffb284">
    <meta name="apple-mobile-web-app-status-bar-style" content="#ffb284">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="QRCode">
    <!--<link rel="icon" href="ico.ico" type="image/x-icon">-->
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- RWD -->
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
    <meta http-equiv="Content-Language" content="zh-TW">
    <meta name="Description" content="QRCode" />
    <link rel="manifest" href="manifest.json">
    <link type="text/css" href="css/index.css" rel="stylesheet" />
    <script src="js/jquery-3.4.1.min.js"></script>
    <title>QRCode | 首頁</title>
</head>
<body>
    <div name="index_head">
        <div class="head_div">
            <img class="head_div_img" src="images/ico_2.png">
            <div class="head_div_title">PHP QR Code</div>
        </div>
    </div>
    <div name="index_body" class="body_minheight">
        <div class="body_div">
            <div class="body_div_inputform">
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_title">填入資料</div>
                    <div class="body_div_inputform_div_inputdiv">
                        <input class="body_div_inputform_div_input" autocomplete="off" type="text" name="data" id="form_data" placeholder="*填入資料">
                    </div>
                </div>
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_title">容錯能力</div>
                    <div class="body_div_inputform_div_inputdiv">
                        <select  name="level" id="form_level" class="body_div_inputform_div_input" >
                            <option value="L">L -> 7%</option>
                            <option value="M">M -> 15%</option>
                            <option value="Q">Q -> 25%</option>
                            <option value="H" selected>H -> 30%</option>
                        </select>
                    </div>
                </div>
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_title">大小</div>
                    <div class="body_div_inputform_div_inputdiv">
                        <select  name="size" id="form_size" class="body_div_inputform_div_input" >
                            <?php
                                for ($i=1; $i <= 40; $i++) { 
                                    if($i==10){
                                        echo "<option value='$i' selected>$i</option>";
                                    }else{
                                        echo "<option value='$i'>$i</option>";
                                    }
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_title">邊框</div>
                    <div class="body_div_inputform_div_inputdiv">
                        <select  name="border" id="form_border" class="body_div_inputform_div_input" >
                            <option value='0'>無</option>
                            <?php
                                for ($i=1; $i <= 5; $i++) { 
                                    echo "<option value='$i'>$i</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_title">logo</div>
                    <div class="body_div_inputform_div_inputaddbtn">
                        <div class="body_div_inputform_div_inputaddbtn_input_div">
                            <input autocomplete="off" class="body_div_inputform_div_inputaddbtn_input" type="text" id="file-uploader_inputtext" placeholder="*上傳圖片">
                        </div>
                        <label class="body_div_inputform_div_inputaddbtn_btn_label">
                            <input type="file" id="file-uploader" data-target="file-uploader" accept="image/*" style="display:none;">
                            上傳
                        </label>
                    </div>
                    <!--<div class="body_div_inputform_div_inputdiv">
                        <input class="body_div_inputform_div_input" autocomplete="off" type="text" name="logo" id="form_logo" placeholder="*logo">
                    </div>-->
                </div>
                <div class="body_div_inputform_div">
                    <div class="body_div_inputform_div_btn" id="creat_btn"><div>&nbsp;送出&nbsp;</div></div>
                    <div class="body_div_inputform_div_btn_clear" id="clear_btn"><div>&nbsp;清除&nbsp;</div></div>
                </div>
            </div>
            <div class="body_div_outputform">
                <div id="output_div" class="body_div_outputform_div"></div>
            </div>
        </div>
    </div>
    <div name="index_foot">
        <div class="foot_div">
            <div class="foot_div_detail">
                <div>
                    <div class="foot_div_detail_font">聯絡電話 0989821329</div>
                    <div class="foot_div_detail_font">聯絡信箱 61212good@gmail.com</div>
                    <div class="foot_div_detail_font">週一至週五 09:00-12:30 & 13:30-18:00</div>
                    <div class="foot_div_detail_font">聯絡信箱 61212good@gmail.com</div>
                </div>
            </div>
            <div class="foot_div_title">
                <div>© 2023 &nbsp;www.chiawei.epizy.com</div>
            </div>
        </div>
    </div>
</body>
</html>
<script type="text/javascript">
    $(document).on('click', "[id='creat_btn']", function() {
        var form_data = $("[id='form_data']").val();
        var form_level = $("[id='form_level']").val();
        var form_size = $("[id='form_size']").val();
        var form_border = $("[id='form_border']").val();
        var form_logo = $("[id='file-uploader_inputtext']").val();
        if(form_data==""){
            alert("請填入資料");
            $("[id='form_data']").focus();
            $("[id='output_div']").html("");
            return false;
        }else if(form_logo==""){
            var QRCodehtml = "<img class='output_div_img' src='http://localhost/1.MyProject/phpqrcode/chiawei_createQRcode.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"'><div class='output_div_linkdiv'><a href='http://localhost/1.MyProject/phpqrcode/chiawei_createQRcode.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"' class='output_div_link' target='_blank'>http://localhost/1.MyProject/phpqrcode/chiawei_createQRcode.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"</a><div>";
            console.log(QRCodehtml);
            $("[id='output_div']").html(QRCodehtml);
        }else{
            var QRCodehtml = "<img class='output_div_img' src='http://localhost/1.MyProject/phpqrcode/chiawei_QRLogo.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"&logo="+encodeURIComponent(form_logo)+"'><div class='output_div_linkdiv'><a href='http://localhost/1.MyProject/phpqrcode/chiawei_QRLogo.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"&logo="+encodeURIComponent(form_logo)+"' class='output_div_link' target='_blank'>http://localhost/1.MyProject/phpqrcode/chiawei_QRLogo.php?data="+encodeURIComponent(form_data)+"&level="+form_level+"&size="+form_size+"&border="+form_border+"&logo="+encodeURIComponent(form_logo)+"</a><div>";
            console.log(QRCodehtml);
            $("[id='output_div']").html(QRCodehtml);
        }
    });

    $(document).on('click', "[id='clear_btn']", function() {
        $.ajax({
            type: "POST",
            url: "include/function_ajax.php",
            data:{
                case: "clear_tmp"
            },
            success: function(e){
                console.log(e);
                if(e=="目錄：. 目錄：.. 檔案：LINE.png "){
                    $("[id='output_div']").html("清除成功");
                    $("[id='file-uploader_inputtext']").val("");
                    $("[id='file-uploader']").val("");
                }
                return false;
            },
            error: function() {
                alert("發生錯誤請稍後再試!");
                return false;
            }
        });
    });

    $(document).on('change', '#file-uploader', function() {
        var file = $("#file-uploader").val();
        var fileName = getFileName(file);
        $('#file-uploader_inputtext').val("temp/"+fileName);
        var file_data = $('#file-uploader').prop('files')[0];   //取得上傳檔案屬性
        var form_data = new FormData();  //建構new FormData()
        form_data.append('file', file_data);  //把物件加到file後面
        $.ajax({
            url: 'include/function_ajax.php?case=uploaduserimg',
            type: "POST",
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,    //data只能指定單一物件
            success: function(e){
                console.log(e);
                var pattern = new RegExp('file上傳錯誤');
                var fileurl_head = e.indexOf("userimg_tmpurl=");
                var fileurl = e.substr(fileurl_head+15);

                if(e.match(pattern)){
                    alert("file上傳錯誤!"+'\n'+"注意: 檔案大小不得大於2MB"+'\n'+e);
                }else{
                    //$('#console_userinfo_userimg').css("background","url("+fileurl+")");
                    //$('#console_userinfo_userimg').css("background-size","cover");
                }
                return false;
            },
            error: function() {
                alert("發生錯誤請稍後再試!");
                return false;
            }
        });
        function getFileName(e){
            var pos=e.lastIndexOf("\\");
            return e.substring(pos+1);  
        }
        return false;
    });
</script>