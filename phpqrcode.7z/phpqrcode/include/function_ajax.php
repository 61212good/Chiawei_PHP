<?php
	if (!isset($_SESSION)){
		session_start();
	}
	$case=$_REQUEST['case'];
	switch ($case){
		case 'uploaduserimg':
			if (!empty($_FILES['file'])) {
				if ($_FILES['file']['error'] === 0) {
					foreach ($_FILES['file'] as $key => $value) {
						echo "[".$key."] => ".$value."\n";
					}
					$file = $_FILES['file']['tmp_name'];
					$dest = "../temp/".$_FILES['file']['name'];
					move_uploaded_file($file, $dest);
					echo "userimg_tmpurl=temp/".$_FILES['file']['name'];
				}else{
					echo "file上傳錯誤 -> ".$_FILES['file']['error'];
				}
			}else{
				echo "file上傳錯誤 -> 沒有接收到檔案";
			}
		break;
		case 'clear_tmp':
			foreach (scandir("../temp/") as $item) {
				if($item!="LINE.png"&&!is_dir($item)){
					unlink("../temp/".$item);
				}
			}
			foreach (scandir("../temp/") as $item) {
				if (is_dir($item)) {
					echo "目錄：$item ";
				} else {
					echo "檔案：$item ";
				}
			}
		break;
	}
?>