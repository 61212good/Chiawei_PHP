<?php
    include("qrlib.php");
    if(isset($_GET['data'])&&$_GET['data']!=""){
        $level = isset($_GET['level']) ? $_GET['level'] : 'L';
        $size = isset($_GET['size']) ? $_GET['size'] : '20';
        $border = isset($_GET['border']) ? $_GET['border'] : '1';
        QRcode::png($_GET['data'],FALSE, $level, $size, $border);
    }else{
        echo "Error沒有資料";
    }
?>